<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Inertia\Inertia;
use Inertia\Response;

class RegisteredUserController extends Controller
{
    /**
     * Show the registration page.
     */
    public function create(): Response
    {
        return Inertia::render('auth/register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'username' => 'required|lowercase|max:255|unique:' . User::class,
            'name' => 'required|string|max:255',
            'email' => 'required|string|lowercase|email|gmail:/^[A-Za-z0-9._%+-]+@gmail\.com$/i|max:255|unique:' . User::class,
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'requested_role' => ['required', 'in:User,Operator,Verifikator'],
        ]);

        $user = User::create([
            'username' => $request->username,
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'requested_role' => $request['requested_role'], // disimpan sebagai permintaan
            'role' => 'Guest', // aktif default = Guest
        ]);

        event(new Registered($user));

        Auth::login($user);

        return redirect()->route('login')->with('status', 'Registrasi berhasil. Cek email verifikasi kamu.');
    }
}
